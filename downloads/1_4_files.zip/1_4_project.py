import matplotlib.pyplot as plt
import os.path
import numpy as np
import PIL
import PIL.ImageDraw

#Open the pic of the tiny man taking a selfie
directory = os.path.dirname(os.path.abspath(__file__))  
filepath_tiny = os.path.join(directory, 'tiny.JPG')
tiny_numpy = plt.imread(filepath_tiny)

#Open Ben in numpy
filepath_ben = os.path.join(directory, 'ben.jpg')
ben_numpy = plt.imread(filepath_ben)

#Open Kobe in numpy
filepath_kobe = os.path.join(directory, 'kobe.jpg')
kobe_numpy = plt.imread(filepath_kobe)

# Converts tiny man, Ben, and Kobe numpy pictures to PIL
tiny_image_pil = PIL.Image.fromarray(tiny_numpy)
ben_image_pil = PIL.Image.fromarray(ben_numpy)
kobe_image_pil = PIL.Image.fromarray(kobe_numpy)

# Makes Kobe and Ben's pictures smaller to fit on the tiny man's selfie
ben_img_small = ben_image_pil.resize((120,175))
kobe_img_small = kobe_image_pil.resize((120,175))

# Places Ben and Kobe's pictures next to the tiny guy
tiny_image_pil.paste(ben_img_small,(160,35))
tiny_image_pil.paste(kobe_img_small,(210,340))

tiny_numpy = np.array(tiny_image_pil)

for r in range(420,530):
    for c in range(50,200):
        if sum(tiny_numpy[r][c])>400:
            tiny_numpy[r][c] = [200,0,100]


fig, ax = plt.subplots(1, 1)
ax.plot(75,305,'mo',ms=13)
ax.plot(93,305,'mo',ms=13)
ax.plot(84,325,'mv',ms=17)
ax.plot(363,376,'y*',ms=13)
ax.imshow(tiny_numpy, interpolation='none')
fig.show()


